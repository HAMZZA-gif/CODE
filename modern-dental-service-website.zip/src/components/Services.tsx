import { Sparkles, Zap, Smile, ShieldCheck, Baby, ScanLine } from "lucide-react";

const services = [
  {
    icon: <Sparkles className="w-7 h-7" />,
    title: "Blanchiment Dentaire",
    desc: "Retrouvez un sourire éclatant grâce à nos techniques de blanchiment professionnelles, sans douleur et durables.",
    color: "from-yellow-400 to-amber-500",
    bg: "bg-yellow-50",
    border: "border-yellow-100",
    image: "/images/teeth-whitening.jpg",
  },
  {
    icon: <Zap className="w-7 h-7" />,
    title: "Implants Dentaires",
    desc: "Remplacez vos dents manquantes par des implants de qualité chirurgicale, esthétiques et durables sur le long terme.",
    color: "from-sky-400 to-blue-600",
    bg: "bg-sky-50",
    border: "border-sky-100",
    image: "/images/dental-implants.jpg",
  },
  {
    icon: <Smile className="w-7 h-7" />,
    title: "Orthodontie",
    desc: "Alignez parfaitement vos dents avec nos aligneurs transparents discrets ou nos appareils fixes pour tous les âges.",
    color: "from-violet-400 to-purple-600",
    bg: "bg-violet-50",
    border: "border-violet-100",
    image: "/images/orthodontics.jpg",
  },
  {
    icon: <ShieldCheck className="w-7 h-7" />,
    title: "Soins Préventifs",
    desc: "Détartrage, polissage et bilans réguliers pour maintenir une hygiène bucco-dentaire irréprochable et prévenir les caries.",
    color: "from-emerald-400 to-teal-600",
    bg: "bg-emerald-50",
    border: "border-emerald-100",
    image: null,
  },
  {
    icon: <Baby className="w-7 h-7" />,
    title: "Dentisterie Pédiatrique",
    desc: "Un environnement rassurant et des soins adaptés aux enfants dès le plus jeune âge pour un suivi optimal.",
    color: "from-pink-400 to-rose-500",
    bg: "bg-pink-50",
    border: "border-pink-100",
    image: null,
  },
  {
    icon: <ScanLine className="w-7 h-7" />,
    title: "Radiologie 3D",
    desc: "Bilan radiologique numérique de pointe pour des diagnostics précis et une planification optimale de vos traitements.",
    color: "from-cyan-400 to-blue-500",
    bg: "bg-cyan-50",
    border: "border-cyan-100",
    image: null,
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-sky-50 text-sky-600 font-semibold text-sm mb-4">
            Nos Spécialités
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-5 font-playfair">
            Des soins complets pour toute la famille
          </h2>
          <p className="text-slate-500 text-lg leading-relaxed">
            Nous proposons une gamme étendue de traitements dentaires modernes,
            alliant technologie de pointe et confort patient.
          </p>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((s) => (
            <div
              key={s.title}
              className={`group relative rounded-3xl border ${s.border} ${s.bg} p-8 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden`}
            >
              {/* Background image overlay */}
              {s.image && (
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-500 bg-cover bg-center rounded-3xl"
                  style={{ backgroundImage: `url('${s.image}')` }}
                />
              )}
              {/* Icon */}
              <div
                className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.color} text-white flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300`}
              >
                {s.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">{s.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{s.desc}</p>
              <div className={`mt-6 inline-flex items-center gap-1 text-sm font-semibold bg-gradient-to-r ${s.color} bg-clip-text text-transparent`}>
                En savoir plus →
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
