import { Clock, MapPin, Phone, CalendarCheck } from "lucide-react";

const schedule = [
  { day: "Lundi", hours: "08h00 – 19h00", open: true },
  { day: "Mardi", hours: "08h00 – 19h00", open: true },
  { day: "Mercredi", hours: "08h00 – 18h00", open: true },
  { day: "Jeudi", hours: "08h00 – 19h00", open: true },
  { day: "Vendredi", hours: "08h00 – 17h00", open: true },
  { day: "Samedi", hours: "09h00 – 13h00", open: true },
  { day: "Dimanche", hours: "Fermé", open: false },
];

function getCurrentDay() {
  const days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  return days[new Date().getDay()];
}

export default function Hours() {
  const today = getCurrentDay();

  return (
    <section id="horaires" className="py-24 bg-gradient-to-br from-blue-900 via-blue-800 to-sky-700 relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 left-0 w-96 h-96 rounded-full bg-white/5 blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-sky-400/10 blur-3xl translate-x-1/3 translate-y-1/3" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 text-blue-200 font-semibold text-sm mb-4">
            Horaires d'ouverture
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-4 font-playfair">
            Nous sommes là pour vous
          </h2>
          <p className="text-blue-200 text-lg">
            Consultez nos horaires et venez nous rendre visite au cabinet.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 items-start">
          {/* Schedule table */}
          <div className="bg-white/10 backdrop-blur-md rounded-3xl border border-white/20 overflow-hidden shadow-2xl">
            <div className="p-6 border-b border-white/10 flex items-center gap-3">
              <Clock className="w-5 h-5 text-sky-300" />
              <h3 className="text-white font-semibold text-lg">Horaires hebdomadaires</h3>
            </div>
            <div className="divide-y divide-white/10">
              {schedule.map((item) => {
                const isToday = item.day === today;
                return (
                  <div
                    key={item.day}
                    className={`flex items-center justify-between px-6 py-4 transition-colors ${
                      isToday ? "bg-white/20" : "hover:bg-white/5"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {isToday && (
                        <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                      )}
                      <span className={`font-medium ${isToday ? "text-white" : "text-blue-200"}`}>
                        {item.day}
                      </span>
                      {isToday && (
                        <span className="text-xs bg-sky-400/20 text-sky-300 px-2 py-0.5 rounded-full font-medium">
                          Aujourd'hui
                        </span>
                      )}
                    </div>
                    <span
                      className={`text-sm font-semibold ${
                        item.open
                          ? isToday
                            ? "text-sky-300"
                            : "text-blue-100"
                          : "text-red-400"
                      }`}
                    >
                      {item.hours}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Info cards */}
          <div className="space-y-5">
            {/* Urgences */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-white font-semibold">Urgences dentaires</h4>
                <p className="text-blue-200 text-sm mt-1">
                  En cas d'urgence, appelez notre ligne dédiée disponible 24h/24.
                </p>
                <a href="tel:+33800123456" className="inline-block mt-2 text-red-400 font-bold text-lg hover:text-red-300 transition-colors">
                  0800 123 456
                </a>
              </div>
            </div>

            {/* Adresse */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-sky-400/20 text-sky-300 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-white font-semibold">Notre adresse</h4>
                <p className="text-blue-200 text-sm mt-1">
                  12 Rue de la Paix, 75001 Paris
                </p>
                <p className="text-blue-300 text-xs mt-1">
                  Métro : Opéra (lignes 3, 7, 8) – Parking gratuit disponible
                </p>
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block mt-2 text-sky-400 text-sm font-semibold hover:text-sky-300"
                >
                  Voir sur la carte →
                </a>
              </div>
            </div>

            {/* RDV */}
            <div className="bg-gradient-to-br from-sky-400 to-blue-500 rounded-2xl p-6 flex gap-4 shadow-xl shadow-blue-900/30">
              <div className="w-12 h-12 rounded-xl bg-white/20 text-white flex items-center justify-center flex-shrink-0">
                <CalendarCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-white font-semibold">Réservation en ligne</h4>
                <p className="text-blue-100 text-sm mt-1">
                  Prenez rendez-vous à tout moment, en toute simplicité.
                </p>
                <a
                  href="#contact"
                  className="inline-block mt-3 px-5 py-2 bg-white text-blue-700 rounded-full text-sm font-bold hover:bg-blue-50 transition-colors shadow-md"
                >
                  Réserver maintenant
                </a>
              </div>
            </div>

            {/* Map placeholder */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden h-48">
              <iframe
                title="Localisation SmileCare"
                src="https://www.openstreetmap.org/export/embed.html?bbox=2.327%2C48.868%2C2.337%2C48.873&layer=mapnik&marker=48.8705%2C2.332"
                className="w-full h-full border-0 opacity-80"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
