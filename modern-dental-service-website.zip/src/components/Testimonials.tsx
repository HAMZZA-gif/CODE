import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Marie L.",
    role: "Patiente depuis 3 ans",
    text: "Un cabinet exceptionnel ! L'accueil est toujours chaleureux et le Dr. Mercier est très professionnelle. Mes implants sont parfaits, je recommande vivement à toute ma famille.",
    rating: 5,
    initials: "ML",
    gradient: "from-sky-400 to-blue-500",
  },
  {
    name: "Julien P.",
    role: "Patient depuis 5 ans",
    text: "J'avais une peur panique du dentiste avant de découvrir SmileCare. L'équipe est tellement rassurante et attentionnée que mes visites sont devenues agréables. Merci infiniment !",
    rating: 5,
    initials: "JP",
    gradient: "from-violet-400 to-purple-600",
  },
  {
    name: "Sophie K.",
    role: "Maman de 2 enfants",
    text: "Mes enfants adorent venir ici ! La pédodontiste est fantastique avec les enfants. Le cabinet est moderne, propre et très bien équipé. Je ne changerais pour rien au monde.",
    rating: 5,
    initials: "SK",
    gradient: "from-pink-400 to-rose-500",
  },
  {
    name: "Antoine M.",
    role: "Cadre, 38 ans",
    text: "Traitement Invisalign impeccable en 14 mois. Résultat bluffant et suivi très rigoureux à chaque étape. Toute l'équipe est disponible et répond rapidement aux questions.",
    rating: 5,
    initials: "AM",
    gradient: "from-emerald-400 to-teal-500",
  },
  {
    name: "Clara B.",
    role: "Étudiante en médecine",
    text: "Les tarifs sont compétitifs et la prise en charge mutuelle est très bien expliquée. J'ai fait un blanchiment et les résultats sont spectaculaires. Je suis ravie !",
    rating: 5,
    initials: "CB",
    gradient: "from-amber-400 to-orange-500",
  },
  {
    name: "François D.",
    role: "Retraité, 67 ans",
    text: "Une équipe à l'écoute, patiente et très compétente. Après 30 ans de peur du dentiste, j'ai enfin trouvé un cabinet où je me sens en confiance. Bravo à tous !",
    rating: 5,
    initials: "FD",
    gradient: "from-cyan-400 to-sky-600",
  },
];

export default function Testimonials() {
  return (
    <section id="temoignages" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-yellow-50 text-yellow-600 font-semibold text-sm mb-4">
            Témoignages patients
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-5 font-playfair">
            Ce que disent nos patients
          </h2>
          <div className="flex items-center justify-center gap-2 mb-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} className="w-6 h-6 text-yellow-400 fill-yellow-400" />
            ))}
            <span className="ml-2 font-bold text-slate-800 text-lg">4.9/5</span>
            <span className="text-slate-400 text-sm">(+250 avis Google)</span>
          </div>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="bg-slate-50 rounded-3xl p-7 border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative"
            >
              {/* Quote icon */}
              <Quote className="w-8 h-8 text-blue-100 absolute top-6 right-6" />

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              <p className="text-slate-600 text-sm leading-relaxed italic mb-6">
                "{t.text}"
              </p>

              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-full bg-gradient-to-br ${t.gradient} text-white flex items-center justify-center text-sm font-bold flex-shrink-0`}
                >
                  {t.initials}
                </div>
                <div>
                  <p className="font-semibold text-slate-900 text-sm">{t.name}</p>
                  <p className="text-slate-400 text-xs">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
