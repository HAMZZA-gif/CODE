import { Mail, Globe } from "lucide-react";

const team = [
  {
    name: "Dr. Sophie Mercier",
    role: "Chirurgien-Dentiste & Directrice",
    specialty: "Implantologie • Esthétique",
    initials: "SM",
    gradient: "from-sky-400 to-blue-600",
  },
  {
    name: "Dr. Thomas Laurent",
    role: "Orthodontiste",
    specialty: "Invisalign • Appareils fixes",
    initials: "TL",
    gradient: "from-violet-400 to-purple-600",
  },
  {
    name: "Dr. Camille Dubois",
    role: "Pédodontiste",
    specialty: "Dentisterie enfant & ado",
    initials: "CD",
    gradient: "from-pink-400 to-rose-500",
  },
  {
    name: "Dr. Marc Benali",
    role: "Parodontologue",
    specialty: "Soins des gencives",
    initials: "MB",
    gradient: "from-emerald-400 to-teal-600",
  },
];

export default function Team() {
  return (
    <section id="equipe" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <span className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-blue-600 font-semibold text-sm mb-4">
              Notre Équipe
            </span>
            <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-5 font-playfair">
              Des experts à votre service
            </h2>
            <p className="text-slate-500 text-lg leading-relaxed">
              Notre équipe pluridisciplinaire de chirurgiens-dentistes et
              spécialistes est à votre écoute pour vous offrir les meilleurs
              soins avec bienveillance et professionnalisme.
            </p>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-2xl h-72 lg:h-80">
            <img
              src="/images/dentist-team.jpg"
              alt="Notre équipe dentaire"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member) => (
            <div
              key={member.name}
              className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-slate-100"
            >
              {/* Avatar */}
              <div
                className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${member.gradient} text-white flex items-center justify-center text-2xl font-bold mb-5 shadow-lg`}
              >
                {member.initials}
              </div>
              <h3 className="font-bold text-slate-900 text-lg leading-tight">{member.name}</h3>
              <p className="text-sky-600 text-sm font-medium mt-1">{member.role}</p>
              <p className="text-slate-400 text-xs mt-2">{member.specialty}</p>

              <div className="flex items-center gap-3 mt-5 pt-5 border-t border-slate-100">
                <button className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center hover:bg-sky-100 transition-colors">
                  <Mail className="w-4 h-4" />
                </button>
                <button className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center hover:bg-blue-100 transition-colors">
                  <Globe className="w-4 h-4" />
                </button>
                <a
                  href="#contact"
                  className="ml-auto text-xs font-semibold text-sky-600 hover:text-sky-700"
                >
                  Consulter →
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
