import { ArrowRight, Star, Shield, Award } from "lucide-react";

export default function Hero() {
  return (
    <section
      id="accueil"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('/images/hero-dental.jpg')" }}
      />
      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/85 via-blue-800/70 to-sky-700/40" />

      {/* Decorative circles */}
      <div className="absolute top-32 right-10 w-72 h-72 rounded-full bg-sky-400/10 blur-3xl" />
      <div className="absolute bottom-20 left-10 w-96 h-96 rounded-full bg-blue-600/10 blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6 py-32 grid lg:grid-cols-2 gap-16 items-center">
        {/* Left content */}
        <div className="text-white space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-sm font-medium text-blue-100">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            Cabinet dentaire de confiance depuis 2005
          </div>

          <h1 className="text-5xl lg:text-6xl font-bold leading-tight font-playfair">
            Votre Sourire,{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-300 to-blue-200">
              Notre Passion
            </span>
          </h1>

          <p className="text-lg text-blue-100/90 leading-relaxed max-w-lg">
            Une équipe de spécialistes dévoués vous accueille dans un cadre
            moderne et chaleureux pour des soins dentaires d'excellence adaptés
            à toute la famille.
          </p>

          {/* Buttons */}
          <div className="flex flex-wrap gap-4">
            <a
              href="#contact"
              className="inline-flex items-center gap-2 px-7 py-4 rounded-full bg-gradient-to-r from-sky-400 to-blue-500 text-white font-semibold text-base shadow-xl shadow-blue-800/40 hover:shadow-blue-700/60 hover:scale-105 transition-all duration-200"
            >
              Prendre rendez-vous
              <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="#services"
              className="inline-flex items-center gap-2 px-7 py-4 rounded-full bg-white/10 backdrop-blur-sm border border-white/30 text-white font-semibold text-base hover:bg-white/20 transition-all duration-200"
            >
              Nos services
            </a>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-8 pt-4">
            {[
              { value: "5000+", label: "Patients satisfaits" },
              { value: "20+", label: "Années d'expérience" },
              { value: "8", label: "Spécialistes" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl font-bold text-white">{stat.value}</p>
                <p className="text-sm text-blue-200 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Right card */}
        <div className="hidden lg:flex justify-end">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-8 shadow-2xl w-80 space-y-6">
            <h3 className="text-white font-semibold text-lg">Pourquoi nous choisir ?</h3>
            {[
              { icon: <Shield className="w-5 h-5 text-sky-300" />, title: "Soins sécurisés", desc: "Protocoles rigoureux et équipements certifiés" },
              { icon: <Star className="w-5 h-5 text-yellow-400" />, title: "Expertise reconnue", desc: "Équipe diplômée et formée aux dernières techniques" },
              { icon: <Award className="w-5 h-5 text-emerald-400" />, title: "Prix transparents", desc: "Devis gratuit et prise en charge mutuelle" },
            ].map((item) => (
              <div key={item.title} className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                  {item.icon}
                </div>
                <div>
                  <p className="text-white font-medium text-sm">{item.title}</p>
                  <p className="text-blue-200 text-xs mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
            <a
              href="#contact"
              className="block text-center w-full px-5 py-3 rounded-full bg-white text-blue-700 font-semibold text-sm hover:bg-blue-50 transition-colors shadow-lg"
            >
              Consultation gratuite
            </a>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 80H1440V30C1200 70 960 80 720 60C480 40 240 10 0 30V80Z" fill="white" />
        </svg>
      </div>
    </section>
  );
}
