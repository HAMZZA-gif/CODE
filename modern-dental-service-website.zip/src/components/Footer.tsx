import { Phone, Mail, MapPin, Share2, Heart, PlayCircle } from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-slate-900 text-slate-400">
      <div className="max-w-7xl mx-auto px-6 pt-16 pb-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center shadow-lg">
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6 text-white" stroke="currentColor" strokeWidth={1.8}>
                  <path d="M12 2C9 2 6 4.5 6 7.5c0 1.5.5 3 1.2 4.2L9 18c.5 2 1.5 4 3 4s2.5-2 3-4l1.8-6.3C17.5 10.5 18 9 18 7.5 18 4.5 15 2 12 2z" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div>
                <span className="font-bold text-xl text-white leading-none block">SmileCare</span>
                <span className="text-xs text-blue-400">Dentistry</span>
              </div>
            </div>
            <p className="text-sm leading-relaxed">
              Votre cabinet dentaire de confiance à Paris. Soins modernes, équipe bienveillante et tarifs transparents depuis 2005.
            </p>
            <div className="flex gap-3">
              {[Share2, Heart, PlayCircle].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-sky-500 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-5 text-sm uppercase tracking-wider">Services</h4>
            <ul className="space-y-3 text-sm">
              {["Blanchiment dentaire", "Implants dentaires", "Orthodontie", "Soins préventifs", "Pédodontie", "Radiologie 3D"].map((s) => (
                <li key={s}>
                  <a href="#services" className="hover:text-sky-400 transition-colors">
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Liens */}
          <div>
            <h4 className="text-white font-semibold mb-5 text-sm uppercase tracking-wider">Informations</h4>
            <ul className="space-y-3 text-sm">
              {["Notre équipe", "Tarifs & mutuelles", "Urgences dentaires", "Espace patient", "Mentions légales", "Politique de confidentialité"].map((l) => (
                <li key={l}>
                  <a href="#" className="hover:text-sky-400 transition-colors">
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-5 text-sm uppercase tracking-wider">Contact</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex gap-3">
                <MapPin className="w-4 h-4 text-sky-400 flex-shrink-0 mt-0.5" />
                <span>12 Rue de la Paix<br />75001 Paris, France</span>
              </li>
              <li className="flex gap-3 items-center">
                <Phone className="w-4 h-4 text-sky-400 flex-shrink-0" />
                <a href="tel:+33123456789" className="hover:text-sky-400 transition-colors">
                  01 23 45 67 89
                </a>
              </li>
              <li className="flex gap-3 items-center">
                <Mail className="w-4 h-4 text-sky-400 flex-shrink-0" />
                <a href="mailto:contact@smilecare.fr" className="hover:text-sky-400 transition-colors">
                  contact@smilecare.fr
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p>© {year} SmileCare Dentistry. Tous droits réservés.</p>
          <p className="text-slate-600">
            Conçu avec ❤️ pour votre sourire
          </p>
        </div>
      </div>
    </footer>
  );
}
