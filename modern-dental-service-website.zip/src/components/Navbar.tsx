import { useState, useEffect } from "react";
import { Phone, Menu, X } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { label: "Accueil", href: "#accueil" },
    { label: "Services", href: "#services" },
    { label: "Notre Équipe", href: "#equipe" },
    { label: "Horaires", href: "#horaires" },
    { label: "Témoignages", href: "#temoignages" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-md shadow-md py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#accueil" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-200 group-hover:scale-105 transition-transform">
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6 text-white" stroke="currentColor" strokeWidth={1.8}>
              <path d="M12 2C9 2 6 4.5 6 7.5c0 1.5.5 3 1.2 4.2L9 18c.5 2 1.5 4 3 4s2.5-2 3-4l1.8-6.3C17.5 10.5 18 9 18 7.5 18 4.5 15 2 12 2z" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div>
            <span className={`font-bold text-xl leading-none ${scrolled ? "text-blue-700" : "text-white"}`}>
              SmileCare
            </span>
            <p className={`text-xs leading-none ${scrolled ? "text-blue-400" : "text-blue-200"}`}>Dentistry</p>
          </div>
        </a>

        {/* Desktop links */}
        <ul className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <li key={l.label}>
              <a
                href={l.href}
                className={`text-sm font-medium transition-colors hover:text-sky-400 ${
                  scrolled ? "text-slate-700" : "text-white/90"
                }`}
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <div className="hidden lg:flex items-center gap-3">
          <a
            href="tel:+33123456789"
            className={`flex items-center gap-2 text-sm font-medium transition-colors ${
              scrolled ? "text-slate-600" : "text-white/80"
            } hover:text-sky-400`}
          >
            <Phone className="w-4 h-4" />
            01 23 45 67 89
          </a>
          <a
            href="#contact"
            className="px-5 py-2.5 rounded-full bg-gradient-to-r from-sky-400 to-blue-600 text-white text-sm font-semibold shadow-lg shadow-blue-200 hover:shadow-blue-300 hover:scale-105 transition-all duration-200"
          >
            Prendre RDV
          </a>
        </div>

        {/* Mobile burger */}
        <button
          className={`lg:hidden p-2 rounded-lg ${scrolled ? "text-slate-700" : "text-white"}`}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="lg:hidden bg-white border-t border-slate-100 shadow-xl">
          <ul className="flex flex-col p-6 gap-4">
            {links.map((l) => (
              <li key={l.label}>
                <a
                  href={l.href}
                  className="text-slate-700 font-medium hover:text-sky-500 transition-colors"
                  onClick={() => setMenuOpen(false)}
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#contact"
                className="block text-center px-5 py-3 rounded-full bg-gradient-to-r from-sky-400 to-blue-600 text-white font-semibold"
                onClick={() => setMenuOpen(false)}
              >
                Prendre RDV
              </a>
            </li>
          </ul>
        </div>
      )}
    </nav>
  );
}
