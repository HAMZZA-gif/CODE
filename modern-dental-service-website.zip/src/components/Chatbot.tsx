import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";

type Message = {
  id: number;
  from: "bot" | "user";
  text: string;
};

const FAQ: { keywords: string[]; answer: string }[] = [
  {
    keywords: ["horaire", "ouvert", "ouverture", "heure", "fermé", "ferme"],
    answer:
      "🕐 Nos horaires d'ouverture :\n• Lundi – Jeudi : 08h00 – 19h00\n• Vendredi : 08h00 – 17h00\n• Samedi : 09h00 – 13h00\n• Dimanche : Fermé\n\nPour les urgences, appelez le **0800 123 456** (24h/24).",
  },
  {
    keywords: ["rendez-vous", "rdv", "réserver", "réservation", "appointment", "prendre"],
    answer:
      "📅 Vous pouvez prendre rendez-vous :\n• En ligne via notre formulaire de contact\n• Par téléphone au **01 23 45 67 89**\n• Du lundi au samedi pendant nos horaires d'ouverture\n\nNous vous confirmons votre rendez-vous sous 24h.",
  },
  {
    keywords: ["prix", "tarif", "coût", "coute", "combien", "mutuelle", "remboursement", "sécu", "sécurité sociale"],
    answer:
      "💰 Nos tarifs sont transparents et compétitifs :\n• Consultation : à partir de 25€ (prise en charge Sécu)\n• Détartrage : inclus dans le remboursement\n• Blanchiment : à partir de 290€\n• Devis gratuit pour implants et orthodontie\n\nNous acceptons toutes les mutuelles. Un devis personnalisé vous sera remis lors de la consultation.",
  },
  {
    keywords: ["urgence", "urgent", "douleur", "mal", "cassé", "cassée"],
    answer:
      "🚨 En cas d'urgence dentaire :\n• Appelez notre ligne urgences : **0800 123 456** (disponible 24h/24)\n• Nous faisons de notre mieux pour vous recevoir le jour même\n• Ne prenez pas d'ibuprofène si vous êtes à jeun\n\nSi la douleur est insupportable, rendez-vous aux urgences hospitalières.",
  },
  {
    keywords: ["implant", "implants"],
    answer:
      "🦷 Nos implants dentaires :\n• Technologie de dernière génération\n• Pose sous anesthésie locale, indolore\n• Durée de vie : 15 à 20 ans avec bon entretien\n• Consultation et devis gratuits\n• Financement possible en plusieurs fois\n\nConsultez le Dr. Mercier pour une évaluation personnalisée.",
  },
  {
    keywords: ["blanchiment", "blanchir", "blanc", "tache", "taches"],
    answer:
      "✨ Notre blanchiment dentaire professionnel :\n• Résultats visibles dès la 1ère séance\n• Technique douce et sans douleur\n• Durée : 1h environ\n• À partir de 290€\n• Idéal avant un mariage ou événement spécial\n\nUn bilan préalable est nécessaire pour vérifier l'éligibilité.",
  },
  {
    keywords: ["enfant", "enfants", "bébé", "bebe", "pédiatrique", "pediatrique", "pédodontiste"],
    answer:
      "👶 Soins pédiatriques chez SmileCare :\n• Accueil des enfants dès 3 ans\n• Cabinet décoré et rassurant\n• Notre pédodontiste, le Dr. Dubois, est spécialisée\n• Techniques adaptées pour zéro stress\n• 1er bilan recommandé dès les premières dents\n\nNous adorons accueillir nos petits patients !",
  },
  {
    keywords: ["orthodontie", "appareil", "aligneur", "invisalign", "bague"],
    answer:
      "😁 Orthodontie chez SmileCare :\n• Aligneurs transparents (Invisalign) pour adultes\n• Appareils fixes pour enfants et adolescents\n• Durée de traitement : 6 à 24 mois\n• Suivi mensuel par le Dr. Laurent\n• Prise en charge partielle pour les mineurs\n\nConsultation d'orthodontie gratuite sur demande.",
  },
  {
    keywords: ["adresse", "où", "ou", "situé", "situe", "localisation", "trouver", "emplacement"],
    answer:
      "📍 Nous sommes situés au :\n**12 Rue de la Paix, 75001 Paris**\n\n• Métro : Opéra (lignes 3, 7, 8)\n• Bus : lignes 42, 52, 66\n• Parking gratuit disponible\n• Accès PMR facilité\n\nN'hésitez pas à nous appeler pour obtenir l'itinéraire exact.",
  },
  {
    keywords: ["covid", "hygiène", "protocole", "sécurité", "securite", "propre"],
    answer:
      "🛡️ Nos protocoles sanitaires :\n• Stérilisation de tous les instruments entre chaque patient\n• Port du masque recommandé en salle d'attente\n• Ventilation et purification de l'air dans toutes les salles\n• Gel hydroalcoolique disponible à l'entrée\n• Surfaces désinfectées régulièrement\n\nVotre sécurité est notre priorité absolue.",
  },
];

const SUGGESTED = [
  "Quels sont vos horaires ?",
  "Comment prendre RDV ?",
  "Quels sont vos tarifs ?",
  "Urgence dentaire",
];

function getBotResponse(input: string): string {
  const lower = input.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  for (const faq of FAQ) {
    if (faq.keywords.some((kw) => lower.includes(kw))) {
      return faq.answer;
    }
  }
  return "Merci pour votre question ! 😊 Je ne suis pas sûr de pouvoir y répondre automatiquement. Pour une réponse personnalisée, vous pouvez :\n• 📞 Appeler le **01 23 45 67 89**\n• 💬 Remplir notre formulaire de contact\n• 🕐 Nous rendre visite pendant nos horaires d'ouverture\n\nEst-ce que je peux vous aider avec autre chose ?";
}

const WELCOME: Message = {
  id: 0,
  from: "bot",
  text: "Bonjour ! 👋 Je suis l'assistant virtuel de SmileCare Dentistry.\n\nJe suis là pour répondre à vos questions sur nos services, horaires, tarifs et bien plus encore. Comment puis-je vous aider aujourd'hui ?",
};

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
      setTimeout(() => inputRef.current?.focus(), 200);
    }
  }, [open, messages]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: Date.now(), from: "user", text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      const response = getBotResponse(text);
      setMessages((prev) => [...prev, { id: Date.now() + 1, from: "bot", text: response }]);
      setTyping(false);
    }, 900 + Math.random() * 400);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  const formatText = (text: string) => {
    return text.split("\n").map((line, i) => {
      const boldLine = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      return (
        <span key={i} className="block" dangerouslySetInnerHTML={{ __html: boldLine }} />
      );
    });
  };

  return (
    <>
      {/* Chat toggle button */}
      <button
        onClick={() => setOpen(!open)}
        className={`fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 ${
          open
            ? "bg-slate-700 hover:bg-slate-800 scale-90"
            : "bg-gradient-to-br from-sky-400 to-blue-600 hover:scale-110 shadow-blue-300"
        }`}
        aria-label="Ouvrir le chatbot"
      >
        {open ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <MessageCircle className="w-7 h-7 text-white" />
        )}
        {!open && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full border-2 border-white animate-pulse" />
        )}
      </button>

      {/* Chat window */}
      {open && (
        <div className="fixed bottom-28 right-6 z-50 w-[360px] max-w-[calc(100vw-2rem)] rounded-3xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col bg-white"
          style={{ height: "520px" }}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-sky-500 to-blue-700 px-5 py-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-sm">Assistant SmileCare</p>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                <p className="text-blue-100 text-xs">En ligne – Répond instantanément</p>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="text-white/70 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.from === "user" ? "flex-row-reverse" : "flex-row"}`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    msg.from === "bot"
                      ? "bg-gradient-to-br from-sky-400 to-blue-600"
                      : "bg-gradient-to-br from-slate-400 to-slate-600"
                  }`}
                >
                  {msg.from === "bot" ? (
                    <Bot className="w-4 h-4 text-white" />
                  ) : (
                    <User className="w-4 h-4 text-white" />
                  )}
                </div>
                {/* Bubble */}
                <div
                  className={`max-w-[78%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-sm ${
                    msg.from === "bot"
                      ? "bg-white text-slate-700 rounded-tl-sm border border-slate-100"
                      : "bg-gradient-to-br from-sky-500 to-blue-600 text-white rounded-tr-sm"
                  }`}
                >
                  {formatText(msg.text)}
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {typing && (
              <div className="flex gap-2.5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-white rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm border border-slate-100">
                  <div className="flex gap-1 items-center h-4">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"
                        style={{ animationDelay: `${i * 0.15}s` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Suggested questions */}
          {messages.length <= 1 && (
            <div className="px-4 py-2 bg-white border-t border-slate-100">
              <p className="text-xs text-slate-400 mb-2">Questions fréquentes :</p>
              <div className="flex flex-wrap gap-1.5">
                {SUGGESTED.map((q) => (
                  <button
                    key={q}
                    onClick={() => sendMessage(q)}
                    className="text-xs px-3 py-1.5 rounded-full bg-sky-50 text-sky-600 border border-sky-100 hover:bg-sky-100 transition-colors font-medium"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <form
            onSubmit={handleSend}
            className="flex items-center gap-2 px-4 py-3 bg-white border-t border-slate-100"
          >
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Posez votre question..."
              className="flex-1 text-sm bg-slate-50 rounded-xl px-4 py-2.5 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent transition-all text-slate-700 placeholder-slate-400"
            />
            <button
              type="submit"
              disabled={!input.trim() || typing}
              className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 text-white flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed hover:scale-105 transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
