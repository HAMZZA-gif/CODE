import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Sparkles, Stethoscope, Baby, Smile, Syringe, HeartPulse, Scissors, ShieldCheck } from "lucide-react"

const services = [
  {
    icon: Stethoscope,
    title: "Soins Généraux",
    description: "Examens complets, détartrages, traitements des caries et soins préventifs pour maintenir une santé bucco-dentaire optimale.",
    image: "/images/service-general.jpg"
  },
  {
    icon: Sparkles,
    title: "Blanchiment Dentaire",
    description: "Retrouvez un sourire éclatant grâce à nos techniques de blanchiment professionnelles, sûres et efficaces.",
    image: "/images/service-blanchiment.jpg"
  },
  {
    icon: Smile,
    title: "Implants & Prothèses",
    description: "Solutions durables et esthétiques pour remplacer les dents manquantes avec des implants de dernière génération.",
    image: "/images/service-implant.jpg"
  },
  {
    icon: Baby,
    title: "Orthodontie",
    description: "Alignement dentaire pour enfants et adultes avec des solutions invisibles et traditionnelles adaptées à chaque cas.",
    image: "/images/service-orthodontie.jpg"
  },
  {
    icon: Syringe,
    title: "Chirurgie Dentaire",
    description: "Extractions complexes, greffes osseuses et interventions chirurgicales réalisées avec précision et confort.",
    image: "/images/service-chirurgie.jpg"
  },
  {
    icon: HeartPulse,
    title: "Parodontologie",
    description: "Traitement des maladies des gencives et des tissus de soutien des dents pour une santé bucco-dentaire durable.",
    image: "/images/service-parodontie.jpg"
  },
  {
    icon: Scissors,
    title: "Esthétique Dentaire",
    description: "Facettes, couronnes céramiques et corrections esthétiques pour un sourire harmonieux et naturel.",
    image: "/images/service-esthetique.jpg"
  },
  {
    icon: ShieldCheck,
    title: "Urgences Dentaires",
    description: "Prise en charge rapide des urgences : douleurs aiguës, traumatismes dentaires et infections nécessitant une intervention immédiate.",
    image: "/images/service-urgence.jpg"
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Nos Services</span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4 text-balance">
            Des soins complets pour toute la famille
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Nous proposons une gamme complète de services dentaires utilisant les dernières technologies 
            pour vous offrir les meilleurs soins possibles.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <Card key={service.title} className="group overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="h-48 overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-3">
                  <service.icon className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg font-serif">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground leading-relaxed">
                  {service.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
