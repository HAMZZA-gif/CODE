import { Button } from "@/components/ui/button"
import { Calendar, Shield, Award } from "lucide-react"
import { AppointmentDialog } from "@/components/dental/appointment-dialog"

export function Hero() {
  return (
    <section id="accueil" className="relative min-h-screen flex items-center pt-20">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: "url('/images/hero-dental.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/80 to-white/40" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Award className="w-4 h-4" />
            Excellence en soins dentaires depuis 2005
          </div>

          {/* Heading */}
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6 text-balance">
            Votre sourire mérite les meilleurs soins
          </h1>

          {/* Description */}
          <p className="text-lg text-muted-foreground mb-8 leading-relaxed max-w-xl">
            Notre équipe de dentistes experts vous accompagne avec des technologies de pointe 
            et une approche personnalisée pour des soins dentaires d&apos;exception.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <AppointmentDialog>
              <Button size="lg" className="text-base px-8">
                <Calendar className="w-5 h-5 mr-2" />
                Prendre rendez-vous
              </Button>
            </AppointmentDialog>
            <Button size="lg" variant="outline" className="text-base px-8" asChild>
              <a href="#services">Découvrir nos services</a>
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                <Shield className="w-6 h-6 text-accent-foreground" />
              </div>
              <div>
                <p className="font-semibold text-foreground">+15 000</p>
                <p className="text-sm text-muted-foreground">Patients satisfaits</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                <Award className="w-6 h-6 text-accent-foreground" />
              </div>
              <div>
                <p className="font-semibold text-foreground">20 ans</p>
                <p className="text-sm text-muted-foreground">D&apos;expérience</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
