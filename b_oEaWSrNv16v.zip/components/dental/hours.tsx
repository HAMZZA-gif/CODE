import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, MapPin, Phone, Mail } from "lucide-react"

const hours = [
  { day: "Lundi", hours: "09:00 - 19:00" },
  { day: "Mardi", hours: "09:00 - 19:00" },
  { day: "Mercredi", hours: "09:00 - 19:00" },
  { day: "Jeudi", hours: "09:00 - 19:00" },
  { day: "Vendredi", hours: "09:00 - 18:00" },
  { day: "Samedi", hours: "09:00 - 13:00" },
  { day: "Dimanche", hours: "Fermé" },
]

export function Hours() {
  const today = new Date().toLocaleDateString('fr-FR', { weekday: 'long' })
  const capitalizedToday = today.charAt(0).toUpperCase() + today.slice(1)

  return (
    <section id="horaires" className="py-24 bg-primary/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Column - Hours */}
          <div>
            <span className="text-primary font-medium text-sm uppercase tracking-wider">Horaires</span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-8">
              Heures d&apos;ouverture
            </h2>

            <Card className="border-0 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="w-5 h-5 text-primary" />
                  Nos horaires
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {hours.map((schedule) => (
                    <div 
                      key={schedule.day}
                      className={`flex justify-between py-3 border-b border-border last:border-0 ${
                        schedule.day === capitalizedToday ? 'bg-primary/10 -mx-4 px-4 rounded-lg' : ''
                      }`}
                    >
                      <span className={`font-medium ${
                        schedule.day === capitalizedToday ? 'text-primary' : 'text-foreground'
                      }`}>
                        {schedule.day}
                        {schedule.day === capitalizedToday && (
                          <span className="ml-2 text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                            Aujourd&apos;hui
                          </span>
                        )}
                      </span>
                      <span className={`${
                        schedule.hours === 'Fermé' ? 'text-muted-foreground' : 'text-foreground'
                      }`}>
                        {schedule.hours}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Contact Info */}
          <div>
            <span className="text-primary font-medium text-sm uppercase tracking-wider">Contact</span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-8">
              Nous trouver
            </h2>

            <div className="space-y-6">
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">Adresse</h3>
                      <p className="text-muted-foreground">
                        123 Avenue des Champs-Élysées<br />
                        75008 Paris, France
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Phone className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">Téléphone</h3>
                      <a href="tel:+33123456789" className="text-primary hover:underline">
                        01 23 45 67 89
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Mail className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">Email</h3>
                      <a href="mailto:contact@cabinet-sourire.fr" className="text-primary hover:underline">
                        contact@cabinet-sourire.fr
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
