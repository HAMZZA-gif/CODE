import { Card, CardContent } from "@/components/ui/card"

const team = [
  {
    name: "Dr. Marie Dupont",
    role: "Chirurgien-Dentiste",
    specialty: "Implantologie & Esthétique",
    image: "/images/dentist-1.jpg",
  },
  {
    name: "Dr. Pierre Martin",
    role: "Orthodontiste",
    specialty: "Orthodontie Adulte & Enfant",
    image: "/images/dentist-2.jpg",
  },
  {
    name: "Dr. Sophie Bernard",
    role: "Parodontiste",
    specialty: "Soins des Gencives",
    image: "/images/dentist-3.jpg",
  },
]

export function Team() {
  return (
    <section id="equipe" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Notre Équipe</span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4 text-balance">
            Des experts à votre service
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Notre équipe de professionnels qualifiés vous accueille dans un environnement chaleureux 
            et vous accompagne avec expertise et bienveillance.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {team.map((member) => (
            <Card key={member.name} className="group overflow-hidden border-0 shadow-lg">
              <div className="h-80 overflow-hidden">
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardContent className="p-6 text-center">
                <h3 className="font-serif text-xl font-bold text-foreground mb-1">{member.name}</h3>
                <p className="text-primary font-medium text-sm mb-1">{member.role}</p>
                <p className="text-muted-foreground text-sm">{member.specialty}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
