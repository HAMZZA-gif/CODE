"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MessageCircle, X, Send, Bot, User } from "lucide-react"

interface Message {
  role: "user" | "assistant"
  content: string
}

const quickQuestions = [
  "Quels sont vos horaires ?",
  "Comment prendre RDV ?",
  "Quels services proposez-vous ?",
  "Où êtes-vous situés ?",
]

// Simple rule-based responses for the dental chatbot
function getResponse(message: string): string {
  const lowerMessage = message.toLowerCase()

  if (lowerMessage.includes("horaire") || lowerMessage.includes("heure") || lowerMessage.includes("ouvert")) {
    return "Nos horaires d'ouverture sont :\n• Lundi - Jeudi : 09h00 - 19h00\n• Vendredi : 09h00 - 18h00\n• Samedi : 09h00 - 13h00\n• Dimanche : Fermé\n\nN'hésitez pas à nous appeler au 01 23 45 67 89 pour toute question !"
  }

  if (lowerMessage.includes("rdv") || lowerMessage.includes("rendez-vous") || lowerMessage.includes("réserver")) {
    return "Pour prendre rendez-vous, vous pouvez :\n• Nous appeler au 01 23 45 67 89\n• Nous envoyer un email à contact@cabinet-sourire.fr\n• Cliquer sur le bouton 'Prendre RDV' en haut de la page\n\nNous vous répondrons dans les plus brefs délais !"
  }

  if (lowerMessage.includes("service") || lowerMessage.includes("soin") || lowerMessage.includes("traitement")) {
    return "Nous proposons une gamme complète de services dentaires :\n• Soins généraux (détartrage, caries, examens)\n• Blanchiment dentaire professionnel\n• Implants et prothèses dentaires\n• Orthodontie (adultes et enfants)\n• Soins des gencives\n\nQuel service vous intéresse particulièrement ?"
  }

  if (lowerMessage.includes("adresse") || lowerMessage.includes("situé") || lowerMessage.includes("où") || lowerMessage.includes("localisation")) {
    return "Notre cabinet est situé au :\n📍 123 Avenue des Champs-Élysées, 75008 Paris\n\nNous sommes facilement accessibles en métro (lignes 1, 2 et 6) et disposons d'un parking à proximité."
  }

  if (lowerMessage.includes("prix") || lowerMessage.includes("tarif") || lowerMessage.includes("coût") || lowerMessage.includes("combien")) {
    return "Nos tarifs varient selon les soins. Voici quelques exemples :\n• Consultation : à partir de 30€\n• Détartrage : à partir de 50€\n• Blanchiment : à partir de 250€\n\nNous acceptons la plupart des mutuelles. Contactez-nous pour un devis personnalisé !"
  }

  if (lowerMessage.includes("urgence") || lowerMessage.includes("douleur") || lowerMessage.includes("mal")) {
    return "En cas d'urgence dentaire, appelez-nous immédiatement au 01 23 45 67 89. Nous réservons toujours des créneaux pour les urgences.\n\nSi vous avez une douleur intense en dehors des heures d'ouverture, vous pouvez contacter le service de garde dentaire au 01 43 37 51 00."
  }

  if (lowerMessage.includes("bonjour") || lowerMessage.includes("salut") || lowerMessage.includes("hello")) {
    return "Bonjour ! 👋 Bienvenue au Cabinet Dentaire Sourire. Je suis votre assistant virtuel. Comment puis-je vous aider aujourd'hui ?\n\nVous pouvez me poser des questions sur nos horaires, services, tarifs, ou comment prendre rendez-vous."
  }

  if (lowerMessage.includes("merci") || lowerMessage.includes("au revoir") || lowerMessage.includes("bye")) {
    return "Merci pour votre visite ! 😊 N'hésitez pas à nous contacter si vous avez d'autres questions. À bientôt au Cabinet Dentaire Sourire !"
  }

  return "Je comprends votre question. Pour vous aider au mieux, pourriez-vous me donner plus de détails ? Sinon, n'hésitez pas à nous appeler au 01 23 45 67 89 ou à envoyer un email à contact@cabinet-sourire.fr pour une assistance personnalisée."
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Bonjour ! 👋 Je suis l'assistant virtuel du Cabinet Dentaire Sourire. Comment puis-je vous aider aujourd'hui ?",
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async (messageText?: string) => {
    const textToSend = messageText || input.trim()
    if (!textToSend) return

    const userMessage: Message = { role: "user", content: textToSend }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate typing delay
    await new Promise((resolve) => setTimeout(resolve, 800 + Math.random() * 500))

    const response = getResponse(textToSend)
    const assistantMessage: Message = { role: "assistant", content: response }
    setMessages((prev) => [...prev, assistantMessage])
    setIsTyping(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 z-50 w-16 h-16 bg-primary text-primary-foreground rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center ${
          isOpen ? "scale-0" : "scale-100"
        }`}
        aria-label="Ouvrir le chat"
      >
        <MessageCircle className="w-7 h-7" />
      </button>

      {/* Chat Window */}
      <div
        className={`fixed bottom-6 right-6 z-50 w-full max-w-md transition-all duration-300 ${
          isOpen ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none"
        }`}
      >
        <Card className="shadow-2xl border-0 overflow-hidden">
          {/* Header */}
          <CardHeader className="bg-primary text-primary-foreground p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="text-base font-semibold">Assistant Sourire</CardTitle>
                  <p className="text-xs text-primary-foreground/80">En ligne • Répond instantanément</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-primary-foreground/20 rounded-full transition-colors"
                aria-label="Fermer le chat"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            {/* Messages */}
            <div className="h-80 overflow-y-auto p-4 space-y-4 bg-muted/30">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex gap-2 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {message.role === "assistant" && (
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-primary" />
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-md"
                        : "bg-card text-card-foreground shadow-sm rounded-bl-md"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-line">{message.content}</p>
                  </div>
                  {message.role === "user" && (
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-4 h-4 text-primary-foreground" />
                    </div>
                  )}
                </div>
              ))}
              {isTyping && (
                <div className="flex gap-2 justify-start">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                  <div className="bg-card px-4 py-3 rounded-2xl rounded-bl-md shadow-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Questions */}
            {messages.length <= 2 && (
              <div className="px-4 py-3 border-t border-border bg-card">
                <p className="text-xs text-muted-foreground mb-2">Questions fréquentes :</p>
                <div className="flex flex-wrap gap-2">
                  {quickQuestions.map((question) => (
                    <button
                      key={question}
                      onClick={() => handleSend(question)}
                      className="text-xs bg-secondary text-secondary-foreground px-3 py-1.5 rounded-full hover:bg-primary hover:text-primary-foreground transition-colors"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-4 border-t border-border bg-card">
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Tapez votre message..."
                  className="flex-1"
                />
                <Button onClick={() => handleSend()} size="icon" disabled={!input.trim() || isTyping}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  )
}
