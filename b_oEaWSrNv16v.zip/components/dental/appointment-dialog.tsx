"use client"

import { useState } from "react"
import { format } from "date-fns"
import { fr } from "date-fns/locale"
import { Calendar } from "@/components/ui/calendar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Calendar as CalendarIcon, Clock, Check } from "lucide-react"

const services = [
  "Consultation générale",
  "Détartrage",
  "Blanchiment dentaire",
  "Implants dentaires",
  "Orthodontie",
  "Soins des gencives",
  "Extraction dentaire",
  "Prothèses dentaires",
]

const timeSlots = [
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
  "17:00",
]

interface AppointmentDialogProps {
  children: React.ReactNode
}

export function AppointmentDialog({ children }: AppointmentDialogProps) {
  const [open, setOpen] = useState(false)
  const [step, setStep] = useState(1)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined)
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [selectedService, setSelectedService] = useState<string>("")
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    notes: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setIsSuccess(true)
  }

  const resetForm = () => {
    setStep(1)
    setSelectedDate(undefined)
    setSelectedTime("")
    setSelectedService("")
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      notes: "",
    })
    setIsSuccess(false)
  }

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen)
    if (!newOpen) {
      setTimeout(resetForm, 300)
    }
  }

  const canProceedStep1 = selectedDate && selectedTime && selectedService
  const canProceedStep2 =
    formData.firstName && formData.lastName && formData.email && formData.phone

  // Disable past dates and weekends
  const disabledDays = [
    { before: new Date() },
    { dayOfWeek: [0, 6] }, // Sunday = 0, Saturday = 6
  ]

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        {isSuccess ? (
          <div className="py-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <DialogHeader>
              <DialogTitle className="text-center text-2xl">
                Rendez-vous confirmé
              </DialogTitle>
              <DialogDescription className="text-center mt-2">
                Votre rendez-vous a été enregistré avec succès.
              </DialogDescription>
            </DialogHeader>
            <div className="mt-6 p-4 bg-muted rounded-lg text-left">
              <p className="font-medium text-foreground">Récapitulatif :</p>
              <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                <li>
                  <span className="font-medium">Date :</span>{" "}
                  {selectedDate &&
                    format(selectedDate, "EEEE d MMMM yyyy", { locale: fr })}
                </li>
                <li>
                  <span className="font-medium">Heure :</span> {selectedTime}
                </li>
                <li>
                  <span className="font-medium">Service :</span>{" "}
                  {selectedService}
                </li>
                <li>
                  <span className="font-medium">Patient :</span>{" "}
                  {formData.firstName} {formData.lastName}
                </li>
              </ul>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Un email de confirmation vous a été envoyé à {formData.email}
            </p>
            <Button className="mt-6" onClick={() => handleOpenChange(false)}>
              Fermer
            </Button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Prendre rendez-vous</DialogTitle>
              <DialogDescription>
                {step === 1
                  ? "Choisissez la date, l'heure et le type de consultation"
                  : "Renseignez vos informations personnelles"}
              </DialogDescription>
            </DialogHeader>

            {/* Progress indicator */}
            <div className="flex items-center gap-2 mb-4">
              <div
                className={`flex-1 h-1 rounded-full ${
                  step >= 1 ? "bg-primary" : "bg-muted"
                }`}
              />
              <div
                className={`flex-1 h-1 rounded-full ${
                  step >= 2 ? "bg-primary" : "bg-muted"
                }`}
              />
            </div>

            {step === 1 ? (
              <div className="space-y-6">
                {/* Service Selection */}
                <div className="space-y-2">
                  <Label>Type de consultation</Label>
                  <Select
                    value={selectedService}
                    onValueChange={setSelectedService}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez un service" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service} value={service}>
                          {service}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Calendar */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4" />
                    Date du rendez-vous
                  </Label>
                  <div className="border rounded-lg p-3 flex justify-center">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      disabled={disabledDays}
                      locale={fr}
                    />
                  </div>
                </div>

                {/* Time Slots */}
                {selectedDate && (
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Heure du rendez-vous
                    </Label>
                    <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                      {timeSlots.map((time) => (
                        <Button
                          key={time}
                          type="button"
                          variant={selectedTime === time ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSelectedTime(time)}
                          className="text-sm"
                        >
                          {time}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-end">
                  <Button
                    onClick={() => setStep(2)}
                    disabled={!canProceedStep1}
                  >
                    Continuer
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Summary */}
                <div className="p-3 bg-muted rounded-lg text-sm">
                  <p className="font-medium text-foreground">
                    {selectedService}
                  </p>
                  <p className="text-muted-foreground">
                    {selectedDate &&
                      format(selectedDate, "EEEE d MMMM yyyy", { locale: fr })}{" "}
                    à {selectedTime}
                  </p>
                </div>

                {/* Form Fields */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Prénom *</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      placeholder="Jean"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Nom *</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      placeholder="Dupont"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="jean.dupont@email.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Téléphone *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="06 12 34 56 78"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes (optionnel)</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Informations complémentaires..."
                    rows={3}
                  />
                </div>

                <div className="flex justify-between pt-2">
                  <Button variant="outline" onClick={() => setStep(1)}>
                    Retour
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={!canProceedStep2 || isSubmitting}
                  >
                    {isSubmitting ? "Confirmation..." : "Confirmer le rendez-vous"}
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
