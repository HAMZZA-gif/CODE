import Link from "next/link"
import { Phone, Mail, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer id="contact" className="bg-foreground text-background py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-6 h-6 text-primary-foreground" fill="currentColor">
                  <path d="M12 2C9.5 2 7.5 4 7.5 6.5C7.5 8 8 9 8.5 10C9 11 9 12 9 13C9 15 8 17 6 19C5.5 19.5 5.5 20.5 6 21C6.5 21.5 7.5 21.5 8 21L12 17L16 21C16.5 21.5 17.5 21.5 18 21C18.5 20.5 18.5 19.5 18 19C16 17 15 15 15 13C15 12 15 11 15.5 10C16 9 16.5 8 16.5 6.5C16.5 4 14.5 2 12 2Z"/>
                </svg>
              </div>
              <div>
                <span className="font-serif text-xl font-bold">Sourire</span>
                <span className="block text-xs text-background/60 -mt-1">Cabinet Dentaire</span>
              </div>
            </Link>
            <p className="text-background/70 text-sm leading-relaxed">
              Votre partenaire de confiance pour des soins dentaires de qualité depuis 2005.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Liens Rapides</h3>
            <ul className="space-y-3">
              {["Accueil", "Services", "Notre Équipe", "Horaires", "Contact"].map((link) => (
                <li key={link}>
                  <Link href={`#${link.toLowerCase().replace(" ", "-")}`} className="text-background/70 hover:text-background text-sm transition-colors">
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4">Nos Services</h3>
            <ul className="space-y-3">
              {["Soins Généraux", "Blanchiment", "Implants", "Orthodontie", "Urgences"].map((service) => (
                <li key={service}>
                  <span className="text-background/70 text-sm">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">Contact</h3>
            <ul className="space-y-4">
              <li>
                <a href="tel:+33123456789" className="flex items-center gap-3 text-background/70 hover:text-background text-sm transition-colors">
                  <Phone className="w-4 h-4" />
                  01 23 45 67 89
                </a>
              </li>
              <li>
                <a href="mailto:contact@cabinet-sourire.fr" className="flex items-center gap-3 text-background/70 hover:text-background text-sm transition-colors">
                  <Mail className="w-4 h-4" />
                  contact@cabinet-sourire.fr
                </a>
              </li>
              <li>
                <span className="flex items-start gap-3 text-background/70 text-sm">
                  <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  123 Avenue des Champs-Élysées<br />75008 Paris
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-background/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-background/60 text-sm">
            © {new Date().getFullYear()} Cabinet Dentaire Sourire. Tous droits réservés.
          </p>
          <div className="flex gap-6">
            <Link href="#" className="text-background/60 hover:text-background text-sm transition-colors">
              Mentions légales
            </Link>
            <Link href="#" className="text-background/60 hover:text-background text-sm transition-colors">
              Politique de confidentialité
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
