"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, Phone } from "lucide-react"
import { AppointmentDialog } from "@/components/dental/appointment-dialog"

const navLinks = [
  { href: "#accueil", label: "Accueil" },
  { href: "#services", label: "Services" },
  { href: "#equipe", label: "Notre Équipe" },
  { href: "#horaires", label: "Horaires" },
  { href: "#contact", label: "Contact" },
]

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 text-primary-foreground" fill="currentColor">
                <path d="M12 2C9.5 2 7.5 4 7.5 6.5C7.5 8 8 9 8.5 10C9 11 9 12 9 13C9 15 8 17 6 19C5.5 19.5 5.5 20.5 6 21C6.5 21.5 7.5 21.5 8 21L12 17L16 21C16.5 21.5 17.5 21.5 18 21C18.5 20.5 18.5 19.5 18 19C16 17 15 15 15 13C15 12 15 11 15.5 10C16 9 16.5 8 16.5 6.5C16.5 4 14.5 2 12 2Z"/>
              </svg>
            </div>
            <div>
              <span className="font-serif text-xl font-bold text-foreground">Sourire</span>
              <span className="block text-xs text-muted-foreground -mt-1">Cabinet Dentaire</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-4">
            <a href="tel:+33123456789" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
              <Phone className="w-4 h-4" />
              01 23 45 67 89
            </a>
            <AppointmentDialog>
              <Button>Prendre RDV</Button>
            </AppointmentDialog>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <nav className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <AppointmentDialog>
                <Button className="mt-2 w-full">Prendre RDV</Button>
              </AppointmentDialog>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
