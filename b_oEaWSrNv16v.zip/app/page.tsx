import { Header } from "@/components/dental/header"
import { Hero } from "@/components/dental/hero"
import { Services } from "@/components/dental/services"
import { Team } from "@/components/dental/team"
import { Hours } from "@/components/dental/hours"
import { Documents } from "@/components/dental/documents"
import { Footer } from "@/components/dental/footer"
import { Chatbot } from "@/components/dental/chatbot"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <Services />
      <Team />
      <Hours />
      <Documents />
      <Footer />
      <Chatbot />
    </main>
  )
}
